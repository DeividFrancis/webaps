<?php
$materia = 'Linguagem Algoritmica';
$intro = 'Conteudo apresentado à disciplina de introdução a linguagem algoritca, do 1º período do Curso de Sistemas de informação, das Faculdades Integradas de Cacoal, sob a orientação do(a) Prof. Natanael Oliveira Filho. e editado pelo academico joao doria';
$imagem = 'url("../_imagens/tecle.gif")';
$tutor = 'Natanael';


include '../_atoms/titulo-subtitulo.php';
$definaMateria = $java;
include '../_organism/header.php';
// ================================================================================
// TODO O CONTEUDO DEVERA SER ESCRITO AQUI
// RESPEITANDO TODO O ESTILO JA ATRIBUIDO
include '../_organism/conteudo/cont-java.php';

// ================================================================================
include '../_organism/footer.php';

 ?>
