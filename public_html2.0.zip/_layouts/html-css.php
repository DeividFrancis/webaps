<?php
$materia = 'Hipertexto e Estilos';
$intro = 'Conteudo apresentado à disciplina Hipertexto e Estilos, do 1º período do Curso de Sistemas de informação, das Faculdades Integradas de Cacoal, sob a orientação do(a) Prof. Natanael Oliveira Filho. e editado pelo academico joao doria';
$imagem = 'url("../_imagens/html.gif")';
$tutor = 'ALBERTO AYRES BENICIO';

$definaMateria = $html;
include ('../_atoms/titulo-subtitulo.php');
$definaMateria = $html;
include '../_organism/header.php';
// ================================================================================
// TODO O CONTEUDO DEVERA SER ESCRITO AQUI
// RESPEITANDO TODO O ESTILO JA ATRIBUIDO
include '../_organism/conteudo/cont-html-css.php';

// ================================================================================
include '../_organism/footer.php';

 ?>
