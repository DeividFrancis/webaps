<?php
$materia = 'Gerência de Projetos';
$intro = 'No mundo atual grandes empresas até mesmo de pequeno, e médio porte necessita de um Gerenciador de Projetos, a qual se torna a peça chave de qualquer futuro comprometedor.
A Gerência de Projetos aplicada a profissionais de “ TI”
(Tecnologia da informação) é tratada  severamente  entre seus componentes tornando assim um ambiente de trabalho
qualificado, organizado, e acima de tudo eficiente.';

$imagem = 'url("../_imagens/paper.gif")';
$tutor = 'willian';

include '../_atoms/titulo-subtitulo.php';
$definaMateria = $turma;
include '../_organism/header.php';
// ================================================================================
// TODO O CONTEUDO DEVERA SER ESCRITO AQUI
// RESPEITANDO TODO O ESTILO JA ATRIBUIDO
include '../_organism/conteudo/cont-projetos.php';

// ================================================================================
include '../_organism/footer.php';

 ?>
