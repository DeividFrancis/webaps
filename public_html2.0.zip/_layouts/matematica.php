<?php
$materia = 'Matemática';
$intro = 'A matemática é essencial em todos os aspectos porém com o início da informatização ela se tornou peça fundamental nos fatores relevantes para a resolução de problemas lógicos, trazendo uma nova área de conhecimento para nós acadêmicos';
$imagem = 'url("../_imagens/mat-pen.gif")';
$tutor = 'Medina';

include '../_atoms/titulo-subtitulo.php';
$definaMateria = $mat;


include '../_organism/header.php';
// ================================================================================
// TODO O CONTEUDO DEVERA SER ESCRITO AQUI
// RESPEITANDO TODO O ESTILO JA ATRIBUIDO
include '../_organism/conteudo/cont-matematica.php';

// ================================================================================
include '../_organism/footer.php';

 ?>
