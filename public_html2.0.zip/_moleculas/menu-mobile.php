<nav class="mobile">
  <a href="javascript:;" class="toggle"><i class="fa fa-bars"></i></a>
  <div class="menu-mobile">
    <ul class="temas">
      <li><a href="../_layouts/matematica.php"><?php echo $materia ?></a></li>
      <?php titulos($definaMateria) ?>
    </ul>
    <ul class="disciplinas">
      <li><a href="../index.php"><i class="fa fa-home"></i>Inicio</a></li>
      <li><a href="../_layouts/java.php"><i class="fa fa-code"></i>Linguagem Algoritimica</a></li>
      <li><a href="../_layouts/matematica.php"><i class="fa fa-calculator"></i>Matemática</a></li>
      <li><a href="../_layouts/turma.php"><i class="fa fa-book"></i>Gerência de Projetos</a></li>
      <li><a href="../_layouts/html-css.php"><i class="fa fa-html5"></i>Hip e Estilos</a></li>
    </ul>
  </div>
</nav>
