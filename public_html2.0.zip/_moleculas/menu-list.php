
    <li><a href="index.php"><i class="fa fa-bars"></i>Home</a></li>
    <li><a href="../_layouts/java.php"><i class="fa fa-"></i>Linguagem Algoritimica<i class="fa fa-caret-down"></i></a>
      <ul class="sub-menu">
        <script type="text/javascript">
          temas(materia[1], n);
        </script>
      </ul>
    </li>
    <li><a href="../_layouts/matematica.php"><i class="fa fa-"></i>Matemática<i id="flip" class="fa fa-caret-down"></i></a>
      <ul class="sub-menu">
        <li><a href="../_layouts/matematica.php#tema-0"><?php echo $mat[0] ?></a></li>
        <li><a href="../_layouts/matematica.php#tema-1"><?php echo $mat[1] ?></a></li>
        <li><a href="../_layouts/matematica.php#tema-2"><?php echo $mat[2] ?></a></li>
        <li><a href="../_layouts/matematica.php#tema-3"><?php echo $mat[3] ?></a></li>
        <li><a href="../_layouts/matematica.php#tema-4"><?php echo $mat[4] ?></a></li>
        <li><a href="../_layouts/matematica.php#tema-5"><?php echo $mat[5] ?></a></li>
        <li><a href="../_layouts/matematica.php#tema-6"><?php echo $mat[6] ?></a></li>
        <li><a href="../_layouts/matematica.php#tema-7"><?php echo $mat[7] ?></a></li>
      </ul>
    </li>
    <li><a href="../_layouts/turma.php"><i class="fa fa-"></i>Gerência de Projetos<i class="fa fa-caret-down"></i></a>
      <ul class="sub-menu">
        <li><a href="../_layouts/turma.php#tema-0"><?php echo $turma[0] ?></a></li>
        <li><a href="../_layouts/turma.php#tema-1"><?php echo $turma[1] ?></a></li>
        <li><a href="../_layouts/turma.php#tema-2"><?php echo $turma[2] ?></a></li>
        <li><a href="../_layouts/turma.php#tema-3"><?php echo $turma[3] ?></a></li>
        <li><a href="../_layouts/turma.php#tema-4"><?php echo $turma[4] ?></a></li>
      </ul>
    </li>
    <li><a href="../_layouts/html-css.php"><i class="fa fa-"></i>Hip e Estilos<i class="fa fa-caret-down"></i></a>
      <ul class="sub-menu">
        <li><a href="../_layouts/html-css.php#tema-0"><?php echo $html[0] ?> </a></li>
        <li><a href="../_layouts/html-css.php#tema-1"><?php echo $html[1] ?></a></li>
        <li><a href="../_layouts/html-css.php#tema-2"><?php echo $html[2] ?></a></li>
        <li><a href="../_layouts/html-css.php#tema-3"><?php echo $html[3] ?></a></li>
        <li><a href="../_layouts/html-css.php#tema-4"><?php echo $html[4] ?></a></li>
        <li><a href="../_layouts/html-css.php#tema-5"><?php echo $html[5] ?></a></li>
        <li><a href="../_layouts/html-css.php#tema-6"><?php echo $html[6] ?></a></li>
      </ul>
    </li>
