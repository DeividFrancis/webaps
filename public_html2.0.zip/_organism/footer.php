</main>
<footer class="rodape-botton">
  <aside class="mgfooter">
      <!-- <div class="">
          <address class="logo">
              <figure><img src="img/logo_unesc.png" alt="LOGO UNESC"/></figure>
          </address>
      </div> -->

      <div class="td-conteudo">
          <div class="block">
              <address>
                  <i class="fa fa-users fa-2x"></i>
                  <span>
                  <p>Academicos</p>
                  <br><br>
                  DEIVID FRANCIS DE OLIVEIRA
                  <br><br>
                  MATHEUS RODRIGUES DE MATOS
                  <br><br>
                  JOÃO VICTOR A. PEREIRA SOUSA
                  <br><br>
                  WENDREY NIKOLAS SOARES DE OLIVEIRA
                  <br><br>
                  LENNON EWERTON BRASIL
                </span>
              </address>
          </div>

          <div class="block">
              <address>
                  <i class="fa fa-envelope fa-2x"></i>
                  <span>
                  <p>E-mail</p>
                  <br><br>
                  deivid_pbro@hotmail.com
                  <br><br>
                  mr.atos@gmail.com
                  <br><br>
                  noryplaygames@hotmail.com
                  <br><br>
                  wendreyzoitim@gmail.com
                  <br><br>
                  lennonbrr@gmail.com
                  </span>
              </address>
          </div>

          <div class="block">
              <address>
                  <i class="fa fa-institution fa-2x"></i>
                  <span>
                    <p>Unesc</p>
                  <br><br>
                  Facudades Integradas de Cacoal
                  <br><br>
                  Sistema de Informação
                  <br><br>
                  Prof. ALBERTO AYRES BENICIO.
                  <br><br>
                  Campus de Cacoal - Ro
                  
                </span>
              </address>
          </div>
      </div> <!--td-cont -->
  </aside>
  <div class="copyright"><small>Copyright © 2017 </small></div>
</footer>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="../bower_components/jquery/dist/jquery.min.js"></script>
<script src="../jquery.js"></script>
</body>
</html>
