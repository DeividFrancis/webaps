<?php





$java = array(
  0 => 'Conceito de Algoritmo',
  1 => 'Introdução à Linguagem Java',
  2 => 'Operadores',
  3 => 'Conceito de Algoritmo',
  4 => 'Criando um Programa',
  5 => 'Exemplo 01',
  6 => '',
  7 => '',
  8 => '',
  9 => '',
  10 => '',

 );

 $mat = array(
    0 => 'Mat. aplicada a computação' ,
    1 => 'Operação com fração' ,
    2 => 'Tabela Verdade' ,
    3 => 'Preposições simples' ,
    4 => 'Preposições compostas' ,
    5 => 'Operações lógicas sobre as proposições' ,
    6 => 'Binários' ,
    7 => 'Lógica Booleana',
    8 => '',
    9 => '',
    10 => '',
  );

$turma = array(
  0 => 'Gerencia de Projetos' ,
  1 => 'O que é Gestão de Porjetos' ,
  2 => 'A Influência de Ger. de Projetos' ,
  3 => 'O que é PMBOK' ,
  4 => 'PMI' ,
  5 => '',
  6 => '',
  7 => '',
  8 => '',
  9 => '',
  10 => '',
 );
$html = array(
  0 => 'Introdução a Hipertexto',
  1 => 'A Linguagem HTML',
  2 => 'Ferramenta de edição HTML' ,
  3 => 'Conceitos básicos de Web-Designer' ,
  4 => 'introção ao CSS' ,
  5 => 'Cores e unidades' ,
  6 => 'Propriedades CSS' ,
  7 => '' ,
  8 => '' ,
  9 => '' ,
  10 => '' ,
);

function temas($materia = '', $temas = 0)
{
  for ($i=0; $i < $n ; $i++) {
    echo $i;
  }
}
 ?>
